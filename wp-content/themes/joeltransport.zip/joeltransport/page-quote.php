<?php get_header(); ?>
<?php echo do_shortcode( '[jt_survey]' ); ?>
<?php get_footer(); ?>
